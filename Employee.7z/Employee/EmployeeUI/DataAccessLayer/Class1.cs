﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DataAccessLayer
{
    public class EmployeeDAL
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;



        static EmployeeDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public EmployeeDAL()
        {
            con = new SqlConnection(conStr);

        }
        public int AddEmployee(Employee eboj)
        {
            int Eid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "Sou.uspAddEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@EId", SqlDbType.Int);
                cmd.Parameters["@EId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@EName", eboj.EmployeeName);
                cmd.Parameters.AddWithValue("@EMail", eboj.EmailId);
                cmd.Parameters.AddWithValue("@ContactNo", eboj.ContactNo);
                cmd.Parameters.AddWithValue("@Designation", eboj.Designation);
                

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                Eid = int.Parse(cmd.Parameters["@EId"].Value.ToString());
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return Eid;
        }

        public bool EditEmployee(Employee eboj)
        {
            bool result = false;
            try
            {
                // con = new SqlConnection();
                //   con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Sou.uspEditEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@EId", eboj.EmployeeId);
                cmd.Parameters.AddWithValue("@EName", eboj.EmployeeName);
                cmd.Parameters.AddWithValue("@EMail", eboj.EmailId);
                cmd.Parameters.AddWithValue("@ContactNo", eboj.ContactNo);
                cmd.Parameters.AddWithValue("@Designation", eboj.Designation);
                

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }

        public bool DeleteEmployee(int EmployeeId)
        {
            bool result = false;
            try
            {
                //  con = new SqlConnection();
                // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Sou.uspDeleteEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@EId", EmployeeId);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (EmployeeException)
            { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }

        public Employee Search(int EmployeeId)
        {
            Employee emp = null;

            try
            {
                //  con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Sou.uspSearchEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EId", EmployeeId);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    emp = new Employee
                    {
                        EmployeeId = int.Parse(dr["EmployeeId"].ToString()),
                        EmployeeName = dr["EmployeeName"].ToString(),
                        EmailId = dr["EmailId"].ToString(),
                        ContactNo = long.Parse(dr["ContactNo"].ToString()),
                        Designation = dr["Designation"].ToString(),
                      
                    };
                    dr.Close();
                }
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return emp;
        }

        public DataTable Display()
        {
            DataTable dt = null;

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Sou.uspGetEmployees";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }

        public DataTable GetDesignation()
        {
            DataTable dt = null;
            try
            {
                // con = new SqlConnection();
                // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Sou.uspGetDesignation1";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (SqlException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
    }
}

