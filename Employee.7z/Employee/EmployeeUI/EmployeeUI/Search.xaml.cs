﻿using BusinessLayer;
using Entity;
using Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeUI
{
    /// <summary>
    /// Interaction logic for Search.xaml
    /// </summary>
    public partial class Search : Window
    {
        public Search()
        {
            InitializeComponent();
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeBL pb = new EmployeeBL();
                Employee emp = pb.Search(int.Parse(txtSearch.Text));
                if (emp != null)
                { 
                    txtName.Text = emp.EmployeeName;
                    txtEmail.Text = emp.EmailId;
                    txtContact.Text = emp.ContactNo.ToString();
                    txtDesignation.Text = emp.Designation.ToString();
                    gb1.Visibility = Visibility.Visible;
                }
                else
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show
                        (string.Format("Product with id {0} does not exists.", txtSearch.Text),
                        "Product Management System");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

        private void btn_Del_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int Eid = int.Parse(txtSearch.Text);
                EmployeeBL eb = new EmployeeBL();
                if (eb.DeleteEmployee(Eid))
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show("Product Id " + Eid + " was deleted.");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

        private void btn_Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee emp = new Employee
                {
                    EmployeeId = int.Parse(txtSearch.Text),
                    EmployeeName = txtName.Text,
                    EmailId = txtEmail.Text,
                    ContactNo = long.Parse(txtContact.Text),
                    Designation = txtDesignation.Text,
                    
                };
                EmployeeBL eb = new EmployeeBL();
                if (eb.EditEmployee(emp))
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show("Produt Info Saved.", "Product Management System");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }
    }
}
