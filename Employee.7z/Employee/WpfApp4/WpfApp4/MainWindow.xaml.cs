﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        DataSet ds = new DataSet();
        ForeignKeyConstraint fk;

        string connection = @"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_19Sep18_Pune;User ID=sqluser;Password=sqluser";
        static string constr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string query1 = "SELECT * FROM Man_tblCustomers";
            string query2 = "SELECT * FROM Man_tblOrders";

            SqlDataAdapter Man_tblCustomersAdapter = new SqlDataAdapter(query1, constr);
            SqlDataAdapter Man_tblOrdersAdapter = new SqlDataAdapter(query2, constr);

            Man_tblCustomersAdapter.Fill(ds, "Man_tblCustomers");
            Man_tblOrdersAdapter.Fill(ds, "Man_tblOrders");

            dg1.ItemsSource = ds.Tables[0].DefaultView;
            dg2.ItemsSource = ds.Tables["Man_tblOrders"].DefaultView;

            DataColumn parent = ds.Tables["Man_tblCustomers"].Columns["CustomerId"];
            DataColumn child = ds.Tables["Man_tblOrders"].Columns["CustomerId"];

            fk = new ForeignKeyConstraint("FK_Customer_Order", parent, child);
            fk.DeleteRule = Rule.Cascade;
            fk.UpdateRule = Rule.Cascade;
            ds.Tables["Man_tblOrders"].Constraints.Add(fk);

        }
    }
}
